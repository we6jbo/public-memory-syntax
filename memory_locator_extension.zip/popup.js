document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('searchButton').addEventListener('click', searchMemory);
});

async function searchMemory() {
    const query = document.getElementById('searchQuery').value.trim().toLowerCase();
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';

    let found = false;

    // 1. Search GitHub repository: https://github.com/we6jbo/public-memory-syntax
    try {
        const githubResponse = await fetch(`https://api.github.com/repos/we6jbo/public-memory-syntax/contents`);
        const files = await githubResponse.json();
        for (const file of files) {
            if (file.name.toLowerCase().includes(query)) {
                const link = document.createElement('a');
                link.href = file.html_url;
                link.textContent = `GitHub: ${file.name}`;
                link.target = '_blank';
                resultsDiv.appendChild(link);
                resultsDiv.appendChild(document.createElement('br'));
                found = true;
            }
        }
    } catch (e) {
        console.error("GitHub search failed", e);
    }

    // 2. Search X (Twitter) with hashtag #j03-project plus query
    if (!found) {
        const xHashtag = encodeURIComponent(`#j03-project ${query}`);
        const xLink = document.createElement('a');
        xLink.href = `https://twitter.com/search?q=${xHashtag}`;
        xLink.textContent = `Search X (Twitter) for #j03-project ${query}`;
        xLink.target = '_blank';
        resultsDiv.appendChild(xLink);
        resultsDiv.appendChild(document.createElement('br'));
        found = true;
    }

    // 3. Search personal wiki at Miraheze
    if (!found) {
        const mirahezeLink = document.createElement('a');
        mirahezeLink.href = 'https://meta.miraheze.org/wiki/User:PublicMemorySyntax';
        mirahezeLink.textContent = 'Search Personal Wiki at Miraheze';
        mirahezeLink.target = '_blank';
        resultsDiv.appendChild(mirahezeLink);
        resultsDiv.appendChild(document.createElement('br'));
        found = true;
    }

    // 4. Search ebin.pub
    if (!found) {
        const ebinLink = document.createElement('a');
        ebinLink.href = 'https://ebin.pub/sufficiently-educated-from-struggling-to-a-college-degree-0578755602-9780578755601.html';
        ebinLink.textContent = 'Search ebin.pub';
        ebinLink.target = '_blank';
        resultsDiv.appendChild(ebinLink);
        resultsDiv.appendChild(document.createElement('br'));
        found = true;
    }

    // 5. Fallback link to j03.page
    if (!found) {
        const fallbackLink = document.createElement('a');
        fallbackLink.href = 'https://j03.page/j03-project/';
        fallbackLink.textContent = 'Click here to view j03-project page';
        fallbackLink.target = '_blank';
        resultsDiv.appendChild(fallbackLink);
    }
}